/*
 * device.h
 *
 *  Created on: 2020��11��23��
 *      Author: www14
 */

#ifndef SRC_DEVICE_INIT_H_
#define SRC_DEVICE_INIT_H_
extern void device_init();
#endif /* SRC_DEVICE_INIT_H_ */
