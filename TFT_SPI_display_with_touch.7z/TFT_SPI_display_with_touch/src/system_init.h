/*
 * system_init.h
 *
 *  Created on: 2020��11��22��
 *      Author: www14
 */

#ifndef SRC_SYSTEM_INIT_H_
#define SRC_SYSTEM_INIT_H_

extern void system_init();

#endif /* SRC_SYSTEM_INIT_H_ */
