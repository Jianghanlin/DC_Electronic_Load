/*
 * USCI_A0_UART.h
 *
 *  Created on: 2021��1��19��
 *      Author: www14
 */

#ifndef SRC_USCI_A0_UART_H_
#define SRC_USCI_A0_UART_H_

extern void usci_a0_uart_init(void);
extern void usci_a0_uart_tx_isr_handle();

#endif /* SRC_USCI_A0_UART_H_ */
