/*
 * GUI.h
 *
 *  Created on: 2021��1��4��
 *      Author: www14
 */

#ifndef SRC_GUI_H_
#define SRC_GUI_H_

extern void draw_start(void); //��ʼ������ƺ���
extern void CC_Mode(void);
extern void CV_Mode(void);
extern void CR_Mode(void);
extern void CP_Mode(void);
extern void more(void);
extern void Developer_Mode(void);
#endif /* SRC_GUI_H_ */
